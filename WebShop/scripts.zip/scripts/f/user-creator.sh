#!/bin/bash
############################################################
# Help                                                     #
############################################################
Help()
{
   # Display Help
   echo "Create a new user with only one command."
   echo "Arguments beginning with * are under development!"
   echo
   echo "Syntax: user-creator [username] [-s|-d path|-D|-G group|-m user1 user2...]"
   echo "options:"
   echo "-h            Print this Help."
   echo "-s            Add user not to sudo."   
   echo "*-S           Create a System User."
   echo "*-m           Create another new user"
   echo "-D            Create user without home directory."
   echo "*-d [path]    Home an already existing directory as home or create a new home directory with a custom name."
   echo "-G [group]    Add user to specific group."
   echo
}
############################################################
############################################################
# Main program                                             #
############################################################
##########################################################do
(( EUID != 0 )) && exec sudo -- "$0" "$@"
usern=$1

if [ -z $1 ]; then
   read -p 'Username: ' usern
   useradd $usern -m -U -G sudo
   passwd $usern
else
   opt_verbose=false;
   while getopts ':h' option; do
    case $option in
       h) # display Help
          Help
          exit;;
       /?) #Standart options
           read -p 'Username: ' usern
           useradd $usern -m -U -G sudo
           exit;;
    esac
   done
   if [ $2=='-h' ]; then
	  Help
   elif [ $2=='-D' ]; then
          useradd $usern -U -G sudo
   elif [ $2=='-s' ]; then
          useradd $usern -U -m
   elif [ $2=='-G' ]; then
          read -p 'Group: ' SelGroup
          useradd $usern -U -m -G sudo -G $SelGroup
   else
          useradd $usern -m -U -G sudo
   fi
    passwd $usern
fi
